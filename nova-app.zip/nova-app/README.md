# Nova — Deployable AI Agent

This folder has everything needed to put Nova live on your own website:
- `server.js` — backend that keeps your API key hidden and forwards chat requests to Claude
- `public/nova.html` — the frontend (login screen + chat UI)
- `package.json` — dependencies
- `.env.example` — template for your API key

## 1. Get an Anthropic API key

Go to https://console.anthropic.com/settings/keys, sign up/log in, and create a key.
Note: this is pay-as-you-go — you'll be billed for what the app actually uses.

## 2. Run it locally first (recommended)

```bash
cd nova-app
npm install
cp .env.example .env
# open .env and paste your real key after ANTHROPIC_API_KEY=
npm start
```

Open `http://localhost:3000` in your browser — Nova should load and respond to messages.

## 3. Put it on the internet (free options)

Any of these work well for a small app like this:

**Render.com** (easiest, free tier available)
1. Push this folder to a GitHub repo
2. On Render: New → Web Service → connect your repo
3. Build command: `npm install` — Start command: `npm start`
4. Under Environment, add `ANTHROPIC_API_KEY` with your real key
5. Deploy — Render gives you a live URL like `https://nova-yourname.onrender.com`

**Railway.app** (similar flow — connect repo, add the env variable, deploy)

**Your own VPS / hosting** — if you already have server hosting, upload this folder,
run `npm install`, set the environment variable, and run `npm start` (use a process
manager like `pm2` to keep it running).

## 4. Point your domain at it

Once deployed, most hosts (Render, Railway, etc.) let you add a **custom domain**
for free in their dashboard — just add a CNAME record with your domain registrar
pointing to the URL they give you.

## Notes on cost and safety

- The backend includes a basic rate limiter (30 messages per visitor per 10 minutes)
  so one person can't accidentally run up a large bill. Adjust `RATE_LIMIT` in
  `server.js` if you want it looser or stricter.
- Never put your API key directly in `nova.html` or any frontend file — it must
  only live in the backend's environment variables.
- The current login is name/email only, stored in the browser tab's memory —
  it personalizes the interface but isn't a secure account system. If you later
  want real accounts (passwords, saved history across devices), that needs a
  database and proper authentication, which is a bigger next step.
