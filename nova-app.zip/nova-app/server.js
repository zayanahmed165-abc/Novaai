// Nova backend — proxies chat requests to the Claude API.
// The API key lives here (server-side), never in the browser.

const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.ANTHROPIC_API_KEY;

if (!API_KEY) {
  console.warn('WARNING: ANTHROPIC_API_KEY is not set. Set it in a .env file or your host\'s environment variables.');
}

app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.static('public')); // serves nova.html and any other frontend files

// Simple in-memory rate limiter (per IP) so one visitor can't burn through your API budget.
// For real production traffic, replace with a proper rate-limiting service.
const rateLimitMap = new Map();
const RATE_LIMIT = 30; // requests
const RATE_WINDOW_MS = 10 * 60 * 1000; // per 10 minutes

function isRateLimited(ip) {
  const now = Date.now();
  const entry = rateLimitMap.get(ip) || { count: 0, windowStart: now };
  if (now - entry.windowStart > RATE_WINDOW_MS) {
    entry.count = 0;
    entry.windowStart = now;
  }
  entry.count += 1;
  rateLimitMap.set(ip, entry);
  return entry.count > RATE_LIMIT;
}

app.post('/api/chat', async (req, res) => {
  try {
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    if (isRateLimited(ip)) {
      return res.status(429).json({ error: 'Too many requests. Please wait a bit and try again.' });
    }

    if (!API_KEY) {
      return res.status(500).json({ error: 'Server is missing its API key. Contact the site owner.' });
    }

    const { system, messages } = req.body;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'messages array is required.' });
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        system: system || undefined,
        messages
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Anthropic API error:', data);
      return res.status(response.status).json({ error: data?.error?.message || 'Upstream API error.' });
    }

    res.json(data);
  } catch (err) {
    console.error('Server error:', err);
    res.status(500).json({ error: 'Something went wrong on the server.' });
  }
});

app.listen(PORT, () => {
  console.log(`Nova backend running on http://localhost:${PORT}`);
});
